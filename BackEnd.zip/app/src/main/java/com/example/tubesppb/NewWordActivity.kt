package com.example.tubesppb

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText

class NewWordActivity : AppCompatActivity() {
    private lateinit var editTitleView: EditText
    private lateinit var editAuthorView: EditText
    private lateinit var editDescView: EditText

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_word)
        editTitleView = findViewById(R.id.title)
        editAuthorView = findViewById(R.id.author)
        editDescView = findViewById(R.id.desc)

        val button = findViewById<Button>(R.id.button_save)
        button.setOnClickListener {
            val replyIntent = Intent()
            if (TextUtils.isEmpty(editTitleView.text) || TextUtils.isEmpty(editAuthorView.text) || TextUtils.isEmpty(editDescView.text)) {
                setResult(Activity.RESULT_CANCELED, replyIntent)
            } else {
                val word = Array<String>(3) {"it = $it"}
                word[0] = editTitleView.text.toString()
                word[1] = editAuthorView.text.toString()
                word[2] = editDescView.text.toString()
                replyIntent.putExtra(EXTRA_REPLY, word)
                setResult(Activity.RESULT_OK, replyIntent)
            }
            finish()
        }
    }

    companion object {
        const val EXTRA_REPLY = "com.example.android.wordlistsql.REPLY"
    }
}