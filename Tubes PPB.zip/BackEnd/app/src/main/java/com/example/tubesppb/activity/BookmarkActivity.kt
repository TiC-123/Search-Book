package com.example.tubesppb.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tubesppb.Application
import com.example.tubesppb.R
import com.example.tubesppb.adapter.BookFavoriteAdapter
import com.example.tubesppb.viewmodel.BookViewModel
import com.example.tubesppb.viewmodel.BookViewModelFactory

class BookmarkActivity : AppCompatActivity() {
    private lateinit var recyclerMark: RecyclerView
    private lateinit var markAdapter: BookFavoriteAdapter
    private val bookViewModel: BookViewModel by viewModels {
        BookViewModelFactory((application as Application).bookRepository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bookmark)

        recyclerMark = findViewById(R.id.bookBookmarkView)
        markAdapter = BookFavoriteAdapter(this)
        recyclerMark.adapter = markAdapter
        recyclerMark.layoutManager = LinearLayoutManager(this)

        bookViewModel.allBooks.observe(this, { books ->
            books?.let { markAdapter.submitList(it) }
        })
    }
}