package com.example.tubesppb.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tubesppb.Application
import com.example.tubesppb.R
import com.example.tubesppb.adapter.BookFavoriteAdapter
import com.example.tubesppb.adapter.BookRecommendAdapter
import com.example.tubesppb.model.BookModel
import com.example.tubesppb.presenter.Search
import com.example.tubesppb.viewmodel.BookViewModel
import com.example.tubesppb.viewmodel.BookViewModelFactory
import com.example.tubesppb.viewmodel.HistoryViewModel
import com.example.tubesppb.viewmodel.HistoryViewModelFactory
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread
import java.util.ArrayList

class RecommendedActivity: AppCompatActivity() {
    private var searchQuery: String? = null
    private lateinit var recyclerRec: RecyclerView
    private lateinit var recAdapter: BookRecommendAdapter
    private lateinit var recommendedData: ArrayList<BookModel>
    private lateinit var search: Search

    private val bookViewModel: BookViewModel by viewModels {
        BookViewModelFactory((application as Application).bookRepository)
    }

    private val recommendViewModel: HistoryViewModel by viewModels {
        HistoryViewModelFactory((application as Application).historyRepository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recommended)

        var query: String
        search = Search(this)
        recommendedData = ArrayList<BookModel>()
        recyclerRec = findViewById(R.id.bookRekomendasiView)
        recyclerRec.layoutManager = LinearLayoutManager(this)

        recommendViewModel.allHistory.observe(this, { history ->
            if (history.isNotEmpty()) {
                searchQuery = history[0].category
                query = search.getQuery(searchQuery!!)

                showRecommended(query)
            }
        })
    }

    private fun showRecommended(query: String) {
        recommendedData.clear()

        doAsync {
            recommendedData = search.parseJson(query, bookViewModel)

            uiThread {
                recAdapter = BookRecommendAdapter(recommendedData, this@RecommendedActivity)
                recyclerRec.adapter = recAdapter
            }
        }
    }
}