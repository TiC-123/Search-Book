package com.example.tubesppb.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.example.tubesppb.R
import com.example.tubesppb.presenter.Request
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class FirstActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_first)

        val start = findViewById<Button>(R.id.buttonMulai)

        start.setOnClickListener {
            doAsync {
                if (!Request().checkConnection(this@FirstActivity)) {
                    uiThread {
                        Toast.makeText(this@FirstActivity, "No Internet Connection!!!", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    val intent = Intent(this@FirstActivity, MainActivity::class.java)

                    uiThread {
                        Toast.makeText(this@FirstActivity, "Internet Connection!!!", Toast.LENGTH_SHORT).show()
                        startActivity(intent)
                    }
                }
            }
        }
    }
}